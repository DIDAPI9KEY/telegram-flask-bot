from flask import Flask, request
import requests

app = Flask(__name__)
TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"

@app.route(f"/{TOKEN}", methods=["POST"])
def respond():
    update = request.get_json()
    chat_id = update["message"]["chat"]["id"]
    message = update["message"]["text"]
    reply = f"You said: {message}"
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    requests.post(url, json={"chat_id": chat_id, "text": reply})
    return "ok"

@app.route("/")
def index():
    return "Bot is running!"
